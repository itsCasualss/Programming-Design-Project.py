JARVIS ANGLED ENCLOSURE V2
Units: mm. Reference dimensions researched November 4, 2026.
This replaces the box-shaped V1 with an angled desktop enclosure inspired
by lostbowgaming's original supplied model. It is a remake, not an exact
copy of the source mesh or its screen-mount arrangement.

OPEN IN FREECAD
1. Extract the entire ZIP.
2. File > Open > Jarvis_Angled_V2.step for the four printable components.
3. For native editing: Macro > Macros; set directory to this folder;
   select Build_Jarvis_Angled_V2.FCMacro and Execute.
   It saves Jarvis_Angled_V2.FCStd beside the macro.
   If asked, choose the folder containing geometry.json.
The macro was syntax checked, not executed in FreeCAD on the author's host.
The CAD solids were generated and checked with CadQuery/Open Cascade.
Do not run the macro over an edited project you want to retain: save your
changes under another filename before generating a fresh document.

FILES
Jarvis_Angled_V2.step: assembled printable parts only.
Jarvis_V2_With_Hardware_REFERENCE.step: includes simplified Pi and screen;
  hardware models are NOT printable parts and are not complete components.
HousingFinal.step: integrated angled housing and base.
RearCover.step: removable cover with integral Pi posts.
ScreenRetainer0/1.step: screen edge retaining strips.
*_FITCHECK.stl: print/export starting orientations, not qualified print jobs.
Original_raspiscreen_reference.stl: source mesh, unchanged and unaligned.
Preview.png: actual CAD geometry, not a product photograph.
geometry.json: named primitive dimensions and operations for the macro.
validation.json: CAD checks for assumed cable-path envelopes.

NOMINAL DIMENSIONS AND EVIDENCE
Pi4B PCB: 85 x 56, mounting holes diameter 2.7 on 58 x 49 centers;
  holes 3.5 from the relevant board edges. Official mechanical drawing:
https://pip.raspberrypi.com/categories/559-mechanical
https://pip-assets.raspberrypi.com/categories/559-mechanical/documents/RP-001185-MD-1-Mechanical%20Drawing.pdf
Pi board thickness 1.6 in the reference model is a design assumption.
Display: Freenove FNK0078A maker's packing-list image shows 12cm x 7.5cm
  (120 x 75 nominal). This is a rounded product size, not a tolerance drawing.
https://store.freenove.com/products/fnk0078
https://store.freenove.com/cdn/shop/files/FNK0078A.PT06_54f03d0a-45ef-47ef-b2bb-fa4f1f9674c4.jpg
Manufacturer tutorial and mounting instructions:
https://docs.freenove.com/projects/fnk0078/en/latest/fnk0078/codes/tutorial/5_7_inch.html
The maker explicitly notes that model revisions may differ.
LED: assumed conventional 5mm round LED. Vishay example package has 5mm
  body and 5.8mm flange. Your actual LED part number is not known.
https://www.vishay.com/docs/83030/tllr5400_tllr5401.pdf

DESIGN DIMENSIONS / ASSUMPTIONS
Display plane: 65 degrees above desk; lean 25 degrees from vertical.
Shell: 132 wide x 100 tall in screen plane x 46 deep; rear cover 3.
Base: 132 x 83; supports sit below the connector access paths.
Screen pocket: 120.6 x 75.6 (0.3 nominal clearance each side).
Front visible window: 116 x 71, overlapping nominal glass border 2/side.
Front lip: 2 thick. Verify this window does not obscure active pixels.
Screen+controller modeled envelope: 7 deep from z=2 through z=9, ASSUMED.
Screen edge strips at z=9 must be spaced to actual assembly thickness;
  only contact mechanically sound border areas with thin protective pads.
  Never tighten a strip onto glass, components, ribbon, or unsupported PCB.
Pi PCB location in screen-local frame: x18..103, y18..74, z20..21.6.
Pi component side faces removable rear cover; USB/Ethernet face LEFT
  and power/HDMI/audio face TOP in the CAD rear-coordinate view.
  Front-view left/right are reversed. Use hardware reference view to orient.
Pi hole centers: x41.5/99.5, y21.5/70.5.
Pi attaches to rear cover posts rather than Freenove's supplied Pi standoffs.
  Do NOT simultaneously screw Pi to the screen; this uses an independent mount.
Pi post contact plane: z21.6; four 5mm-diameter posts, 24.4 long;
  2.1 pilot bores, 8.4 useful depth. Intended for carefully tapped M2.5.
  Post clearance to real components around holes needs physical checking.
Use supplied 100mm DSI ribbon if sufficient; check actual bend path and latch
  access before assembly. The factory power-contact pins, if your revision
  uses them, will NOT touch the Pi in this independent mounting layout.
  Confirm display power requirements for your revision before assembly;
  an insulated GPIO power harness may be required. Do not guess its pinout.
LED: 5.3 through bore, 6.2 flange relief; space behind for insulated leads.
Cover fasteners: four M3 clearance holes 3.4; housing pilot holes 2.5.
Screen retainer fasteners: same M3 clearance/pilot arrangement.
Screws, tapping method and length must be selected after fit check; blind
  pilots must not be bottomed out. No threads or heat-set pockets modeled.
No heatsink/fan/HAT is guaranteed to fit; verify the selected hardware.

PORT ACCESS (SCREEN-LOCAL FRAME)
USB/Ethernet bay: left wall, y12..81, z16..43 (69 x 27).
  Modeled bank plug path y20..76, z22..42, from board toward left exterior.
USB-C, both micro-HDMI and 3.5mm AV: top wall, x24..110, z14..43 (86 x 29).
  Modeled plug path x27..107, z22..38 from board edge toward top exterior.
MicroSD: right wall, y32..60, z12..28 (28 x 16).
  Modeled extraction path y35..57, z14..21 from PCB toward right exterior.
GPIO: rear window x45..96, y15..28 (51 x 13).
  Modeled jumper access x46..95, y17..26 toward rear exterior.
DSI/CSI: internal access by removing rear panel; DSI connects the display.
  A CSI cable can be routed through the open connector bays; no sealed
  camera-specific gland or external connector is included.
These are oversized grouped bays, not exact individual socket silhouettes.
Connector envelopes are allowances, not manufacturer-exact cable models.
Large adapters, right-angle plugs, strain-relief boots and ribbon connectors
may need larger openings. No promise is made for every cable housing.

ASSEMBLY / FIT GATES
1. Verify actual screen width/height/stack thickness and active display area.
2. Test a bezel/retainer section first. Adjust pocket/window/strip height.
3. Test bare Pi and your actual cables against the rear-cover mounts/bays.
4. Resolve display power and ribbon routing BEFORE final enclosed operation.
5. Check LED body/flange, strain relief and resistor insulation.
6. Choose speaker/mic hardware; use external USB/Bluetooth for now.
   No internal speaker or microphone mount has been invented.
7. Only then slice full parts, assess overhangs/supports, and print.
Rear cover's integral posts point toward the front in assembly. For printing,
place the OUTER cover face on the bed so posts grow upward; use slicer rotate.
Housing needs a support/overhang review because screen lip is inclined.
Base stability with cable pull and actual hardware weight remains untested.

EDITING
Macro creates editable boxes, cylinders and boolean operations. Expand
features in the tree and edit the Data tab. Dimensions/placements are NOT
all linked to one parameter: coordinated edits may be needed.
Stand-cheek profiles are generated Part shapes; change their point list in
geometry.json and rerun to alter the angle/profile coherently.
Reference hardware and plug corridors are hidden by default. Select and
press Space to reveal. Hide reference objects before exporting print files.

ATTRIBUTION
Original: FREENOVE 5 Inch Touch Screen Raspberry PI Case, lostbowgaming
https://makerworld.com/en/models/2419253
User-supplied 3MF embeds License=BY-NC-SA, no version specified.
Retain attribution and the same noncommercial/share-alike conditions for
this remake package. Consult original listing for exact version before
redistributing. Changes: rebuilt angled shell/base, detachable rear cover,
independent Pi mounts, screen retainers, LED pocket and connector bays.
Manufacturer source material is referenced by URL, not relicensed here.
