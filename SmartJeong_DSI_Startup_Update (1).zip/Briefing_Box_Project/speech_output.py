"""Generate a WAV, then play through the user's Linux audio session."""
import logging
import shutil
import subprocess
import tempfile
import wave
from pathlib import Path


class Speaker:
    def __init__(self, config):
        self.enabled = config.get('enabled', True)
        self.speed = str(config.get('speed', 165))
        self.voice = str(config.get('voice', 'en-us'))
        self.player = config.get('player', 'auto')
        self.target = config.get('target')

    def speak(self, text):
        if not self.enabled:
            print('[MOCK SPEECH]', text)
            return None  # explicitly simulated, never reported as physical audio success
        try:
            executable = shutil.which('espeak-ng')
            choices = ['pw-play', 'paplay', 'aplay'] if self.player == 'auto' else [self.player]
            player = next((shutil.which(x) for x in choices if shutil.which(x)), None)
            if not executable or not player:
                raise RuntimeError('Install espeak-ng and an audio player')
            with tempfile.TemporaryDirectory(prefix='briefing-') as directory:
                wav = Path(directory) / 'speech.wav'
                subprocess.run([executable, '-s', self.speed, '-v', self.voice, '-w', str(wav), '--stdin'],
                               input=str(text), text=True, check=True, timeout=15, capture_output=True)
                with wave.open(str(wav), 'rb') as audio:
                    duration = audio.getnframes() / audio.getframerate()
                command = [player]
                if self.target:
                    if Path(player).name == 'pw-play': command += ['--target', str(self.target)]
                    elif Path(player).name == 'paplay': command += ['--device', str(self.target)]
                    else: raise RuntimeError('Explicit target requires pw-play or paplay')
                subprocess.run(command + [str(wav)], check=True, timeout=max(60, duration + 15), capture_output=True)
            return True
        except (OSError, RuntimeError, subprocess.SubprocessError) as error:
            logging.warning('SPEECH_FAILURE=%s', type(error).__name__)
            print('[AUDIO FAILURE] Check Linux output and speaker connection.')
            return False
