"""Install desktop startup and a manual launcher for this project."""
from pathlib import Path
import sys
root=Path(__file__).resolve().parent
python=root/'.venv/bin/python'
if not python.exists(): python=Path(sys.executable)
def quote(value):
    return '"'+str(value).replace('\\','\\\\').replace('"','\\"').replace('`','\\`').replace('$','\\$')+'"'
entry='[Desktop Entry]\nType=Application\nName=SmartJeong\nExec='+quote(python)+' '+quote(root/'main.py')+' --dsi --no-audio\nPath='+str(root)+'\nTerminal=false\n'
for folder in [Path.home()/'.config/autostart',Path.home()/'.local/share/applications']:
    folder.mkdir(parents=True,exist_ok=True)
    (folder/'smartjeong.desktop').write_text(entry)
print('Startup enabled for desktop login. Close with Escape or the Close control. Reopen SmartJeong from the application menu.')
