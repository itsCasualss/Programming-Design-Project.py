# SmartJeong update
## Launch on the 5 inch DSI desktop
Activate the existing virtual environment, then run:
python main.py --dsi --no-audio
For paired speaker output, omit --no-audio.
For the microphone and wake word, add --voice after installing the voice models.
--dsi opens the desktop dashboard fullscreen and disables the legacy SPI display.
It does not install an OS display driver or mirror DSI and HDMI. Configure screen placement/mirroring in Raspberry Pi OS.

## Bluetooth
Pair and select the powered speaker in the Pi desktop sound settings.
Run python audio_check.py as the signed-in desktop account, without sudo.
The default speech player is pw-play, then paplay, then aplay.
For predictable routing, set speech.player to pw-play and speech.target to the speaker node name from wpctl status / wpctl inspect. Do not hard-code a transient numeric sink ID.
With paplay use its PulseAudio sink name instead.
A successful process does not prove audible output. Test speaker off/on and three cold boots.
See BLUETOOTH_AUDIO.md.

## Changes
Pwincess Jeong remains the displayed and spoken assistance prompt.
Window branding now reads SmartJeong.
DSI has an explicit launch option.
Keyboard result timeout now honors response_seconds.
Explicit PipeWire/PulseAudio speech targets and an audio test entry point are available.
Austin's vendor source is unchanged.

## Hardware boundary
Local tests do not certify physical DSI, Bluetooth or microphone operation.
