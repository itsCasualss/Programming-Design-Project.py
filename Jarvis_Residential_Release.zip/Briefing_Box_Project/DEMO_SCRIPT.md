# Demonstration recording plan

Aim for a clear 4–6 minute recording, with the actual Pi, OLED, LED, microphone and speaker visible. Do not present `--demo` scripted input as real voice recognition.

1. **Standby:** show the clock and idle LED. Explain the state machine in one sentence.
2. **Schedule:** say Hey Jarvis; wait for the prompt; say Schedule. Show the three controlled events and the DEMO label. Explain that the file is real ICS with daily recurrence.
3. **Pills:** repeat wake/prompt; say Pills. Show next fictional reminders. State that no real medication or taken/missed status is inferred.
4. **Weather:** request live weather with network enabled; show source time, temperature and units.
5. **News:** request live RSS headlines; show that the display paginates long results while speech reads the full briefing.
6. **Timeout:** wake and remain silent. Show the handled error and return to idle.
7. **Service failure:** briefly disable Wi-Fi and request Weather; show unavailable-service recovery. Restore Wi-Fi.
8. **Member 3 defense:** run the standalone Role 3 demo if time permits. Explain legal state transitions, display pagination, queued Tk updates and GPIO patterns.
9. **Enclosure:** show final housing, airflow and port access. This part must use the actual finished enclosure.

If the classroom internet is unavailable, `--voice --offline` is a transparent backup with real voice and clearly labeled weather/news fixtures. It is not evidence of successful live API fetching; retain a separate earlier live-service recording/results if the professor permits it.

Before recording, complete three cold boots and verify the intended audio sink. Have the terminal launch command ready. Avoid spending the recorded demo troubleshooting pairing.
