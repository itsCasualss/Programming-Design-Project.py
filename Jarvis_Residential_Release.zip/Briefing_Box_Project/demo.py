"""Exercise actual parsers, presentation, and state machine using offline fixtures."""
from main import main
if __name__ == '__main__':
    raise SystemExit(main(['--demo']))
