# Sources and dependency notes

Professor source inspected: `project-voice-briefing-assistant(1).docx` (four pages), including requirements, Member 3 scope, 70/30 project rubric and deliverables. Attached syllabus and Programming_Design slides were also inspected for context. Project-specific description takes precedence for this audit; course-weight discrepancies were not resolved by assumption.

Public implementation references checked during the audit:

- openWakeWord repository and model interface: https://github.com/dscripka/openWakeWord
- Pinned `openwakeword==0.6.0` wheel source inspected locally for Model arguments, reset(), ONNX asset selection and declared dependencies.
- Vosk official microphone example: https://github.com/alphacep/vosk-api/blob/master/python/example/test_microphone.py
- Vosk model source: https://alphacephei.com/vosk/models/
- Raspberry Pi configuration/audio: https://www.raspberrypi.com/documentation/computers/configuration.html
- Raspberry Pi audio guidance: https://www.raspberrypi.com/documentation/accessories/audio.html
- Luma OLED usage: https://luma-oled.readthedocs.io/en/latest/python-usage.html
- Recurring iCalendar queries: https://recurring-ical-events.readthedocs.io/en/latest/user-guide/examples.html
- Open-Meteo API: https://open-meteo.com/en/docs
- Sounddevice official API: https://python-sounddevice.readthedocs.io/

Package versions for portable dependencies are pinned in requirements.txt and tested in this environment. Pi/voice dependency ranges remain subject to an actual ARM installation; record the working freeze after Pi qualification. Using ONNX avoids the unused TFLite wheel requirement but does not guarantee every Python/ARM combination has a compatible ONNX wheel.

No downloaded voice models or third-party source packages are redistributed inside this project ZIP. The setup helper retrieves official assets. Calendar, pills, offline weather and RSS fixtures are fictional project data.
