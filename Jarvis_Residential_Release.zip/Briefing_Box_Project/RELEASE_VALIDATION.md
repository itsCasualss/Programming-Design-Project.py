# Residential dashboard release validation

- 46 automated tests passed: service contracts, state machine and failure handling,
  real luma ST7735 initialization/serialization with electrical I/O mocked,
  rendering/pagination, teammate parser/import isolation, personal data labeling,
  time validation and owner-only configuration file permissions.
- Offline four-service scripted controller demo completed successfully.
- Tk dashboard rendered and visually checked under Xvfb at 1280x800 and 800x480:
  idle, awake, response, compact layout. Screenshots are in preview/ and contain
  explicitly labeled synthetic weather data. Fade animation progresses in Tk.
- Updater exercised against a temporary existing project: source updated,
  existing config and reminder data retained, dated backup created.
- All 14 original teammate files compared byte-for-byte with the supplied ZIP.
- Physical Pi, GPIO LED, ST7735, microphone and speaker were NOT available here.
  Automated driver tests do not establish physical display function.
- Private calendar feed and actual reminder values remain for user setup.

TFT investigation: --hdmi previously disabled SPI deliberately. --dual enables
both outputs. GPIO18 backlight control is unnecessary for the documented
resistor-to-3.3V wiring; the driver now receives a no-op backlight callback.
SPI speed is configurable and defaults to 1 MHz. The diagnostic tests 500 kHz
and common offsets/color orders. No electrical root cause is claimed.

Driver reference checked against installed luma and upstream documentation:
https://github.com/rm-hull/luma.lcd/blob/main/luma/lcd/device.py
https://luma-lcd.readthedocs.io/en/latest/
