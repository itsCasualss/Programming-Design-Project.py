# Validation record

Audit date: 2026-10-19. Environment: Linux x86_64, Python 3.12. These are development-container results, not Raspberry Pi measurements.

| Check | Actual outcome |
|---|---|
| Python compileall | Passed for all project Python files |
| Shell syntax (`bash -n install.sh`) | Passed |
| Offline regression suite | 38 tests passed; raw output in reports/software-test-output.txt |
| `python main.py --demo` | Four real parsers + presentation + scripted controller + unknown-input path completed |
| Pinned portable dependencies | Installed successfully and suite rerun |
| Real Vosk model download/load | Passed with official small English model |
| Real openWakeWord ONNX assets/load | Passed with pinned openwakeword 0.6.0 and ONNX Runtime 1.31.0 |
| `tests/model_smoke.py` | Finite wake scores for silence, reset, fixed Vosk grammar and empty silence result passed |
| Live Open-Meteo request | Successful current-condition response; checked schema and structured output |
| Live BBC RSS request | Read timeout, correctly converted to service-unavailable response |
| Alternate NPR feed check | Also read timeout from this environment; default remains configurable BBC |
| OLED software rendering | 14 128×64 frames rendered through the display draw path and visually inspected; text/page markers fit |
| Tkinter import | Passed |
| Actual Tk window rendering | Not verified: no graphical display/Xvfb; attempted system-package setup was blocked by container permissions |
| OpenSCAD starter | Base rendered successfully with synthetic test dimensions; this is syntax/geometry evidence only, not component fit |
| ARM installer and Pi performance | Not run; Pi unavailable |
| Real wake/command acoustics, speaker audibility | Not tested; physical devices unavailable |
| Physical OLED/GPIO, enclosure, boot reconnect | Not tested |

No recorded acoustic accuracy, cold-boot success, latency, or final assembly results are claimed. Model loading does not establish recognition performance. Network fixture tests do not establish classroom connectivity. The news path must be tested on the Pi before the final recording.

Commands to reproduce software checks:

```bash
python -m unittest discover -s tests -p 'test_*.py' -v
python -m compileall -q .
python main.py --demo
# After model installation:
python tests/model_smoke.py
```

The generated package excludes downloaded models, virtual environments, temporary render checks, runtime logs and private configuration. Use setup_models.py on the Pi to retrieve official model assets.
