# Architecture and algorithms

## State machine

`main.py` contains an explicit allowed-transition table. Illegal transitions raise an error. A bounded state history helps testing; rotating logs contain states and error categories, not private briefing contents.

| State | Action | Next state |
|---|---|---|
| Startup | Initialize components and load real voice models when selected | Idle or Error |
| Idle | Display clock/menu hint; wait for wake word | Prompt or Error |
| Prompt | Display choices, speak prompt | Listening or Error |
| Listening | Fixed grammar, maximum eight seconds | Processing or Error |
| Processing | Fetch/validate one service | Output or Error |
| Output | Show/paginate result; speak full briefing | Idle or Error |
| Error | Display and announce failure, then recover | Idle (startup failure exits) |

A `finally` block returns interaction failures to idle. Startup model/device failures exit with a failure code rather than pretending to be ready. No unbounded retry loop runs at full CPU. Keyboard mode and scripted mode are explicit choices.

## Member 3 algorithm: bounded display pagination

1. Normalize OLED text to the supported bitmap character set.
2. Wrap each paragraph at 20 characters.
3. Group lines into pages of four lines.
4. Render title, body and page index within 128×64 pixels.
5. Advance pages using a monotonic clock; retain every page long enough to read.

Time/memory cost is linear in the supplied text length. Service outputs are capped (three events/headlines, finite title length) to bound presentation. ASCII replacement applies only to OLED; Tk retains Unicode. Full text remains in the desktop view and full speech. Text wrapping tests verify no word loss for ordinary text and line/page limits.

## Member 3 integration and Tk threading

The application worker owns I/O, the state machine, OLED, and LED. It sends display messages through a bounded queue. Tk creates and updates widgets only on the main thread, draining that queue with `after()`. Network requests and audio playback cannot freeze Tk's event processing. Voice idle loops call a display tick so the standby clock refreshes.

OLED pages advance while waiting after speech; the current implementation holds the first page during synchronous speech and then cycles through every page. This favors simplicity and avoids concurrent writes to the I²C display. It is deliberate and measurable.

Closing Tk requests shutdown. Voice/keyboard loops poll the stop event. An in-progress bounded network request or audio subprocess may delay worker cleanup; the daemon worker lets the GUI exit promptly. For normal shutdown after a briefing, use `q` in keyboard mode or Ctrl+C in the terminal. Abrupt GUI close is not a substitute for shutting down Pi power.

## Other subsystem algorithms

- Member 1: openWakeWord uses only Hey Jarvis with 16 kHz mono int16 PCM frames of 1,280 samples (80 ms). Reset buffers between wake sessions. Vosk accepts a fixed grammar and rejects unsupported utterances. Audio queues are bounded. Actual false-trigger and recognition rates require microphone testing.
- Member 2 calendar: parse ICS, expand recurrences within the local day's interval, exclude cancelled events, convert time zones and sort before selecting three. Include all-day and ongoing events.
- Member 2 reminders: validate HH:MM values, construct each next occurrence, roll passed times to tomorrow, sort and select three. Never infer ingestion or missed doses.
- Member 2 network: HTTPS, connect/read timeouts, capped payloads and a transfer budget; reject malformed feeds. The budget is checked between chunks; connection/redirect/socket behavior can add time. It is not a hard real-time guarantee.

## Interface contract

Information services return `{ok, kind, data, source, demo}`. Error results carry a user-safe message. `format_briefing()` turns successful data into `{title, speech, display}`. The same result goes to both outputs, preventing independent API calls from disagreeing. Speaker returns `True` for player success, `False` for failure, and `None` for explicit mock speech.

A successful audio process cannot prove acoustic audibility. OLED/GPIO runtime faults degrade visibly to console/Tk and are logged; they remain physical-demo failures to fix.
