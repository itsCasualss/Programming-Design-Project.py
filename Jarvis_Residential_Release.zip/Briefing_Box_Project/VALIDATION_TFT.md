# TFT validation — 2026-10-26 update

This report supersedes earlier OLED validation claims for TFT deployment.

Completed in a fresh Python 3.12 x86_64 virtual environment:
- Installed requirements.txt from scratch; pip check passed.
- 43/43 automated tests passed. See reports/tft-software-tests.txt.
- Real luma.core 2.6.0 and luma.lcd 2.13.0 ST7735 initialization and rendering
  tested with electrical GPIO/SPI I/O mocked, not a mock display driver.
- Asserted 128x160 effective portrait geometry, SPI0 CE0, 4 MHz,
  reset BCM25 and command/data BCM24. Exercised all display state screens.
- TFT initialization succeeded while OLED imports were deliberately prohibited.
- Required display/GPIO write errors raise instead of silently passing.
- Offline application demo completed with simulated hardware and speech;
  four service results plus intentional invalid-command recovery were exercised.
  See reports/tft-offline-demo.txt.
- Python compilation and bash syntax checks passed.

Fixed deployment gaps: explicit spidev and RPi.GPIO requirements, build headers,
OLED import isolation, display-specific error labels, aggregate preflight,
required hardware checks, explicit no-audio mode, and logged verification.
The selected GPIO Zero backend during verify_pi.sh is rpigpio for the user's Pi 4.

NOT validated here: ARM64/Python 3.13 installation/build, actual SPI/GPIO access,
panel controller variant and offsets, physical colors/text/backlight, wiring,
Bluetooth routing/playback, microphone, or wake-word models. Those cannot be
claimed from desktop tests. Run install.sh and verify_pi.sh on the actual Pi.
SPI writes cannot establish that a panel is physically present or displaying.
The microphone-free profile is complete for keyboard/TFT/LED operation; the
optional --voice profile is separate and is not certified by these results.

Upstream references checked:
- https://luma-core.readthedocs.io/en/stable/interface.html
- https://gpiozero.readthedocs.io/en/stable/api_pins.html

Preserve existing config.json, config.local.json, data, and .venv when applying
an update. The targeted extraction instructions update code, requirements,
scripts and START_TFT.md only.
