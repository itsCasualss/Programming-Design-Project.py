"""Bounded local recognition; never silently downgrade a real voice demonstration."""
import json
import queue
import select
import sys
import threading
import time
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
COMMAND_MAP = {'schedule': 'schedule', 'one': 'schedule', '1': 'schedule',
               'pills': 'pills', 'two': 'pills', '2': 'pills',
               'weather': 'weather', 'three': 'weather', '3': 'weather',
               'news': 'news', 'four': 'news', '4': 'news'}


class KeyboardVoiceInterface:
    def __init__(self, stop=None, tick=None):
        self.stop, self.tick = stop or threading.Event(), tick or (lambda: None)
        self.pending = None
        self.lines = queue.Queue()
        # One reader avoids mixing select() with Python's buffered stdin.
        threading.Thread(target=self._reader, daemon=True).start()

    def _reader(self):
        for line in sys.stdin:
            self.lines.put(line.strip().lower())
        self.lines.put(None)

    def _read(self, prompt, timeout=None):
        print(prompt, flush=True)
        deadline = time.monotonic() + timeout if timeout is not None else float('inf')
        while not self.stop.is_set() and time.monotonic() < deadline:
            self.tick()
            try: line = self.lines.get(timeout=.1)
            except queue.Empty: continue
            if line is None or line == 'q': raise KeyboardInterrupt
            return line
        return None

    def wait_for_wake(self):
        line = self._read('Type schedule / pills / weather / news, or ENTER for menu; q quits')
        self.pending = line if line else None
        return line is not None

    def listen_for_command(self, timeout_seconds=8):
        if self.pending is not None:
            line, self.pending = self.pending, None
        else:
            line = self._read('Schedule / Pills / Weather / News (waiting for your choice):')
            while line == '':
                line = self._read('Type a service name:')
        return COMMAND_MAP.get(line)

    def wait_after_result(self, seconds=60):
        # Discard queued key repeats before starting the response interval.
        while not self.lines.empty():
            try:
                queued = self.lines.get_nowait()
                if queued is None or queued == 'q': raise KeyboardInterrupt
            except queue.Empty: break
        self._read('Result stays for 60 seconds. ENTER returns to menu; q quits.', seconds)


class ScriptedVoiceInterface:
    def __init__(self, commands): self.commands = iter(commands)
    def wait_for_wake(self):
        try: self.command = next(self.commands)
        except StopIteration: raise KeyboardInterrupt
        return True
    def listen_for_command(self, timeout_seconds=8): return self.command


class PiVoiceInterface:
    def __init__(self, config, stop=None, tick=None):
        self.config = config
        self.stop, self.tick = stop or threading.Event(), tick or (lambda: None)
        self.sample_rate = 16000
        self.audio_device = config.get('audio_device')
        self.wakeword_name = config.get('wakeword_name', 'hey_jarvis')
        self.threshold = float(config.get('wakeword_threshold', .5))
        self.vosk_path = BASE_DIR / config.get('vosk_model_path', 'models/vosk-model-small-en-us-0.15')
        self.oww, self.vosk = None, None

    def prepare(self):
        import sounddevice as sd
        from openwakeword.model import Model as WakeModel
        from vosk import Model, SetLogLevel
        if not self.vosk_path.is_dir():
            raise RuntimeError('Run setup_models.py before voice mode')
        sd.check_input_settings(device=self.audio_device, channels=1, dtype='int16', samplerate=16000)
        self.oww = WakeModel(wakeword_models=[self.wakeword_name], inference_framework='onnx')
        SetLogLevel(-1)
        self.vosk = Model(str(self.vosk_path))

    @staticmethod
    def _make_callback(audio_queue):
        def callback(indata, frames, time_info, status):
            # Never block PortAudio. A bounded queue prevents unbounded RAM growth.
            try: audio_queue.put_nowait(bytes(indata))
            except queue.Full: pass
        return callback

    def _stream(self, q):
        import sounddevice as sd
        return sd.RawInputStream(samplerate=16000, blocksize=1280, device=self.audio_device,
                                 dtype='int16', channels=1, callback=self._make_callback(q))

    def wait_for_wake(self):
        import numpy as np
        if self.oww is None: self.prepare()
        self.oww.reset()
        q = queue.Queue(maxsize=32)
        last_audio = time.monotonic()
        with self._stream(q):
            while not self.stop.is_set():
                self.tick()
                try: raw = q.get(timeout=.1)
                except queue.Empty:
                    if time.monotonic() - last_audio > 3:
                        raise RuntimeError('Microphone stopped delivering audio')
                    continue
                last_audio = time.monotonic()
                scores = self.oww.predict(np.frombuffer(raw, dtype=np.int16))
                if any(float(score) >= self.threshold for score in scores.values()):
                    return True
        return False

    def listen_for_command(self, timeout_seconds=8):
        from vosk import KaldiRecognizer
        if self.vosk is None: self.prepare()
        grammar = ['schedule', 'pills', 'weather', 'news', 'one', 'two', 'three', 'four', '[unk]']
        recognizer = KaldiRecognizer(self.vosk, 16000, json.dumps(grammar))
        q = queue.Queue(maxsize=32)
        deadline = time.monotonic() + timeout_seconds
        # A new stream/queue starts AFTER the spoken prompt, avoiding old wake audio.
        with self._stream(q):
            while not self.stop.is_set() and time.monotonic() < deadline:
                self.tick()
                try: raw = q.get(timeout=.1)
                except queue.Empty: continue
                if recognizer.AcceptWaveform(raw):
                    text = json.loads(recognizer.Result()).get('text', '').strip().lower()
                    if text: return COMMAND_MAP.get(text)
        final = json.loads(recognizer.FinalResult()).get('text', '').strip().lower()
        return COMMAND_MAP.get(final)


def create_voice_interface(config, stop=None, tick=None):
    if config.get('input_mode', 'keyboard') == 'voice':
        if config.get('command_backend', 'austin') == 'austin':
            from austin_adapter import AustinVoiceInterface
            return AustinVoiceInterface(config, stop, tick)
        return PiVoiceInterface(config, stop, tick)
    return KeyboardVoiceInterface(stop, tick)
