# Requirement and rubric audit

Source: professor's `project-voice-briefing-assistant(1).docx`, four pages, inspected in this session. The attached syllabus and lecture deck contain different course-weight snapshots (70% projects vs 60% on an introductory slide); this package uses the **project-specific rubric** below and does not infer the current course grade weighting.

## Individual portion: 70 percentage points

| Category | Weight | Member 3 evidence in package | Still required from student |
|---|---:|---|---|
| Subsystem functionality/completeness | 40 | OLED interface, Tk dashboard, standby clock, GPIO states, controller, standalone `role3_demo.py` | Demonstrate on actual hardware and explain behavior |
| Algorithm and justification | 10 | Explicit transition table, recovery paths, bounded pagination; `ARCHITECTURE.md` | Trace an interaction and explain algorithm choices |
| Code quality/readability | 10 | Module boundaries, comments, regression tests, typed-by-convention result contracts | Review and adapt code; maintain honest personal development record |
| Features/user experience | 10 | Consistent menu, clock, paginated results, clear error recovery, demo labels | Verify legibility, volume, responsiveness and timeout usability |

## Group portion: 30 percentage points

| Category | Weight | Evidence prepared | Remaining gap |
|---|---:|---|---|
| Hardware engineering + enclosure | 8 | Pin table, breadboard instructions, CAD starter, measurements checklist | Physical assembly, measured final CAD, fabrication, final speaker choice |
| System integration | 12 | Unified controller, structured data and presentation, real local voice pipeline | Real wake-word-to-spoken-and-displayed end-to-end test |
| Pi reliability/performance | 6 | Bounded failures, setup sequence, qualification matrix | ARM install, latency/recognition results, cold boots and soak test |
| Responsible design | 4 | Fictional data, private feed handling, unknown taken status, no stored microphone recordings | Team review and accurate final report |

## Technical requirements

| Requirement | Implementation | Verification status |
|---|---|---|
| Pi 4/5, Linux, Python | Pi 4B target, `install.sh` | Pi unavailable here |
| ≥32 GB microSD | Existing 32 GB plan | Physical confirmation needed |
| Always-on microphone in idle | `PiVoiceInterface.wait_for_wake()` | Code inspected; acoustics unverified |
| Wake word + exact prompt | Hey Jarvis → “How can I assist you?” | Software sequence tested; real voice pending |
| Fixed Schedule/Pills/Weather/News or digits | Vosk grammar and `COMMAND_MAP` | Mapping tested; live recognition pending |
| State machine including failed understanding | `TRANSITIONS`, `cycle()` | Automated tests pass |
| Calendar private ICS feed | HTTPS URL support; default controlled local recurring ICS | Local parsing and mocked remote response tested; actual private account deliberately unused |
| Local medication schedule | `data/pills.json`, timing validation | Boundary/malformed-data tests pass |
| Weather API | Open-Meteo | Fixture/schema tests and live container request passed; verify Pi network |
| RSS news | Bounded fetch plus feedparser | Fixture/malformed/empty-feed tests pass; live requests timed out here, Pi verification pending |
| Dual speech/display | `format_briefing`, `Presenter`, WAV speaker | Software contract tested; acoustic output pending |
| Integrated display | SSD1306 permitted condensed readout; Tk desktop also supplied | Geometry/pagination tests; actual screen pending |
| At least one GPIO element | GPIO17 status LED | Adapter tests; physical LED pending |
| Service/input robustness | Timeouts, safe errors, explicit mock mode | Automated fault injection |
| Custom enclosure housing components | Layout plan and parameterized CAD starter | Not complete; dimensions and fabrication required |

## Deliverables

| Deliverable | Current artifact | Completion condition |
|---|---|---|
| Source/assets + README/setup | Complete folder | Pi qualification |
| Wiring schematic | `WIRING.svg` connection schematic and `WIRING.md` breadboard instructions | Verify actual OLED and as-built wiring |
| CAD files | `cad/enclosure.scad` starter | Fill measurements, add final mounts/grille/retention and export measured final model |
| Responsible-design note | `RESPONSIBLE_DESIGN.md` | Team review |
| Individual Mid Report (Week 4) | `reports/INDIVIDUAL_REPORT_DRAFT.md` | Add truthful dated personal work/evidence; no retroactive fabricated work |
| Group Mid Report (Week 11) | `reports/GROUP_MID_REPORT_DRAFT.md` | Add team assignments, measured progress, risks |
| Final Group Report | `reports/FINAL_REPORT_DRAFT.md` | Fill physical results, enclosure evidence and conclusions |
| Video demonstration | `DEMO_SCRIPT.md` | Record real wake word, all four outputs and timeout path |

The software package is ready to start hardware validation. Calling the whole project submission-ready now would overstate the evidence. Highest-value remaining work is physical integration, a reliable full demo, and your ability to defend Member 3. Extra features are lower priority.
