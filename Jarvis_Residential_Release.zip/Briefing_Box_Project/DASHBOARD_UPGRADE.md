# Jarvis dashboard upgrade — gunmetal edition

## Install from Windows through SSH
Download the latest Jarvis_Residential_Release.zip, replacing the previous local
ZIP. In PowerShell:

```powershell
scp "$env:USERPROFILE\Downloads\Jarvis_Residential_Release.zip" jeong@10.246.12.127:~/Desktop/
ssh jeong@10.246.12.127
```

Quit the running app. In the Pi SSH session:

```bash
unzip -o ~/Desktop/Jarvis_Residential_Release.zip -d ~/Desktop/Jarvis_Residential_Release
cd ~/Desktop/Jarvis_Residential_Release/Briefing_Box_Project
python3 install_update.py ~/Desktop/Briefing_Box_Project
cd ~/Desktop/Briefing_Box_Project
DISPLAY=:0 .venv/bin/python main.py --hdmi --no-audio
```

Existing config/data, models and virtual environment are preserved. A source and
data backup is created. No new Python dependencies are required for this upgrade.

## Everyday controls
- Enter wakes the keyboard-test mode. Service cards fade in and become clickable.
- Type services in SSH as before, or click a card with the Pi's mouse/touch input.
- News opens a chooser: Hot topics gives current top stories; Search accepts typed
  keywords. In SSH you may also type keywords, press Enter for hot topics, or type
  cancel. These are typed options; the voice grammar remains four fixed services.
- Results seek three distinct publisher identities. Fewer matches are labeled.
  This does not guarantee independent reporting or three views of the same event.
- Public Google News RSS is a third-party aggregation service, not open-source
  news content. Feed summaries can be headline-only. Original article links are
  clickable on the monitor. No full-article scraping or generated summaries.
- Add event / Add reminder are on the home screen. Use the Pi's keyboard and
  mouse/touch input to fill the forms. Review & save shows normalized dates/times.
  Entries persist and become available immediately; no app restart is needed.
- Dates accept November 11th, 2026; Nov 11 2026; 2026-11-11; today; tomorrow.
  Times accept 11:20 PM; 11:20pm; 23:20; 2320; 8am. Ambiguous numeric dates ask
  for a month name. Missing-year month-name dates use the current local year.
- Date displays use November 11th, 2026 and 11:20 PM; storage remains machine-readable.
- Forms append local entries. They do not edit/delete entries or modify a provider's
  private calendar. A connected private feed is protected from accidental replacement.
- Reminders are daily schedule information, not alarms or medication adherence tracking.
- Enter / Return home dismisses results. The existing one-minute interval remains.
- In real voice mode, the wake engine controls wake-up; screen service clicks are
  for keyboard mode. Typed news selection is available on-screen after voice News.

## Validation and remaining checks
51 automated tests pass. Coverage includes friendly input, ambiguous/invalid
dates, persistence, three-publisher selection, service contracts and state errors.
Live hot-topic and spaceflight keyword retrieval each returned three publishers.
A transient network timeout was observed; one bounded retry is now included.
Tk was rendered and inspected at monitor and compact sizes, including both forms
and the news chooser. The scripted four-service demo completes.
Austin's original files remain unchanged. TFT code/wiring was not modified in this
upgrade. Physical Pi performance, microphone and speaker still need user testing.
RSS is subject to provider changes and availability; errors recover to home.

Active briefing highlight: the current service has a blue-tinted card, bright border,
bottom accent, and ACTIVE label during processing/results/errors. Returning home
clears it. All four services are covered by a lifecycle regression test.
