# Raspberry Pi bring-up

**Current TFT build:** Follow START_TFT.md first. Skip OLED/I2C detection and use
the SPI screen test. Audio and voice steps below still apply.

Do these stages in order. Do not enable autostart until manual operation passes. Hardware and ARM installation have not been exercised in the development container.

## 1. Inspect the Pi

Boot the existing card if available. Do not overwrite a useful card without backing it up. Use Raspberry Pi OS Desktop for Bluetooth audio and Tkinter. The installer requires aarch64 (64-bit userspace/kernel target); Python 3.11+ is the intended range. Python 3.13 voice wheel availability must be checked on the actual Pi.

```bash
uname -m
python3 --version
cat /etc/os-release
timedatectl
```

Correct the clock/time zone if needed:

```bash
sudo timedatectl set-timezone America/New_York
```

The application's service timezone is also explicitly configured, so reminders do not accidentally use UTC. An inaccurate clock still affects today's events and live weather context.

## 2. Copy and install

Extract the ZIP so `main.py` is at `~/Briefing_Box_Project/main.py`.

```bash
cd ~/Briefing_Box_Project
bash install.sh
source .venv/bin/activate
python main.py --demo
```

The install script enables I²C, installs OS dependencies, then Python packages. It stops on errors. If an ARM/Python wheel is missing, save the full error and OS/Python versions; do not keep installing random replacement packages. The portable demo remains usable with `requirements.txt`.

`openwakeword==0.6.0` deliberately uses `--no-deps` after its ONNX dependencies are installed. `pip check` may report the intentionally absent `tflite-runtime`; it is not used. Other missing dependencies are actual defects. After a successful Pi install, capture the actual environment:

```bash
python -m pip freeze > reports/pi-package-versions.txt
```

## 3. Wire the display and LED

Shut down and disconnect power. Follow `WIRING.md`, then reconnect power.

```bash
ls /dev/i2c-1
i2cdetect -y 1
groups
```

Expect the OLED address, usually `3c` or `3d`. If absent, power off and check labels/wiring before retrying. An address alone does not establish the controller is SSD1306: check the exact module specification. SH1106 requires a different driver.

If needed, grant this user GPIO/I²C access and log out/in:

```bash
sudo usermod -aG gpio,i2c "$USER"
```

## 4. Pair audio and inspect microphone

Follow `BLUETOOTH_AUDIO.md`. Plug in the USB microphone.

```bash
arecord -l
python -c "import sounddevice as sd; print(sd.query_devices())"
```

Use a unique microphone name substring when possible; numeric device IDs may change on reboot. Create `config.local.json` with your actual values. Example structure (replace the name with one returned by the device listing):

```json
{
  "voice": {"input_mode": "keyboard", "audio_device": "ACTUAL UNIQUE USB MIC NAME"},
  "speech": {"player": "pw-play"},
  "display": {"i2c_address": "0x3C", "required": true},
  "gpio": {"required": true}
}
```

```bash
python tests/hardware_test.py
python role3_demo.py --hardware
```

The test asks you to confirm real OLED, LED, and sound behavior. Device enumeration alone is not a microphone test. Its short PCM capture checks that samples arrive; actual recognition comes next.

## 5. Model setup and keyboard integration

```bash
python setup_models.py
python main.py --offline
```

Press Enter, then type one command within eight seconds. `q` exits. Verify each output and pagination. Silence at the command prompt should time out. `--offline` is labeled synthetic weather/news; it still uses real hardware unless disabled in configuration.

Model setup downloads a small English Vosk model and the official ONNX wake-word assets, then loads them. It does not silently download models during normal use. If a model file is corrupt, remove only that failed model file/directory and rerun setup.

## 6. Voice integration

```bash
python main.py --voice --offline
```

Say **Hey Jarvis**, wait for the spoken prompt to finish, then say **Schedule**, **Pills**, **Weather**, or **News** (spoken one/two/three/four also accepted). Wait until idle before another request. The microphone stream closes while speaking, preventing software feedback from queued audio. Physical echo still needs testing.

If 16 kHz mono input is unsupported, select a compatible PortAudio input/device or configure an OS capture conversion. The code does not silently resample an unsupported raw device. A good USB microphone should be validated before changing the algorithm.

Then test network services:

```bash
python main.py --voice
```

## 7. Final qualification

Complete `TEST_PLAN.md` and fill `reports/physical-results.csv`. Save the video and reports listed in `RUBRIC_AUDIT.md`. Add `--tk` on an attached monitor to show the full interface during your defense.

## Optional user service

The included service starts the real voice mode and requires working models/devices. It is a template, not a validated boot configuration. It does not pair/reconnect Bluetooth by itself. For development, start manually from the logged-in desktop.

Only after repeated manual passes:

```bash
mkdir -p ~/.config/systemd/user
cp systemd/briefing-box.service ~/.config/systemd/user/
systemctl --user daemon-reload
systemctl --user start briefing-box.service
journalctl --user -u briefing-box.service -n 50
```

If it passes, enable it with `systemctl --user enable briefing-box.service`. Do not enable lingering as a shortcut: Bluetooth session availability and cold-boot reconnect must be proven for this user. The service omits `--tk` because graphical environment variables are session-dependent; OLED is its display. To stop: `systemctl --user disable --now briefing-box.service`.
