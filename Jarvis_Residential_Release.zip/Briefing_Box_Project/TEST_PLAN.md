# Test and qualification plan

## Automated software gate

```bash
python -m compileall -q .
python -m unittest discover -s tests -p 'test_*.py' -v
python main.py --demo
```

Tests cover service parsing, recurrence, time-zone sorting, malformed inputs, reminder boundaries, no-network paths, consistent output, transitions, audio failure, GPIO/OLED disconnect, and bounded display/audio data handling. Read `VALIDATION.md` for actual execution evidence. Tests do not establish physical performance.

## Pi qualification matrix

Record date, OS/Python, setup and observations in `reports/physical-results.csv`. These are engineering acceptance targets, not professor-stated thresholds.

| Test | Procedure | Target |
|---|---|---|
| OLED/LED | Hardware script and independent Role 3 demo | No clipped text, all pages shown, correct LED patterns |
| Wake detection | 20 attempts at normal demo distance; record misses | At least 18/20 before demonstration; improve if room changes |
| Command recognition | 10 utterances of each option | At least 9/10 per option, no wrong service presented silently |
| Silence/unknown | Five silence tests and five unsupported utterances | Handled error then idle every time |
| All briefings | Real voice through all four services | Speech + display agree; correct demo/live labels |
| Network loss | Disconnect Wi-Fi, request Weather/News | Error without crash; next interaction works after reconnect |
| File failure | Temporarily configure nonexistent local calendar file | Error → idle; restore configuration |
| Bluetooth loss | Switch speaker off during testing | Detect failed player if OS reports failure; verify no hidden HDMI routing |
| Boot | Three cold boots with final speaker setup | Reliable connection/default sink and readiness |
| Soak | 30 minutes idle plus repeated requests | No runaway memory/CPU, false wakes recorded, no stuck state |
| Latency | Time wake→prompt and command→answer for 10 cycles | Record median and worst case; investigate long pauses |
| Enclosure | Run fully assembled with airflow and ports accessible | No loose conductors, stable power, no unacceptable heat or echo |

Never unplug GPIO wires on a powered Pi for fault injection. Runtime disconnections are simulated in software tests; physical rewiring happens only after shutdown and power removal.

## Evidence to retain

Test command output, package versions, truthful dated notes, photos of as-built wiring/enclosure, final CAD, video, and actual metric table. Do not state “all tests passed” if a test was skipped or a console mock replaced hardware.
