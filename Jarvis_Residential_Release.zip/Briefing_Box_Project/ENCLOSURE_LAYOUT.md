# Enclosure planning and measurement gate

The professor requires a custom housing and CAD deliverable. `cad/enclosure.scad` is a parameterized starter with explicit measurement assertions, not a finished fabricated case. It intentionally refuses to render with zero dimensions.

## Layout decision

Place the OLED and status LED on the front, Pi on insulated standoffs, USB/power ports facing accessible walls, and microphone near an acoustic opening. Keep the microphone away from the speaker grille and fan. Leave space above cooling hardware and for cable bends. Avoid running a speaker magnet or loose bare amplifier board over GPIO connections.

During Bluetooth development the speaker may remain outside the case. The final enclosure must be revised for the team's chosen audio components. Do not size a permanent grille around an unspecified amp or speaker housing.

## Measurements required

| Component | Measure in mm |
|---|---|
| Pi/case | Complete bounding box, fan height, mounting centers, standoff clearance |
| OLED | PCB dimensions, active window, mounting holes, header and cable clearance |
| LED | Body diameter and retention style |
| USB mic | Body/plug dimensions, cable exit, microphone port |
| Final audio | Speaker diameter/depth, mounting pattern, grille clearance, amplifier size and wiring |
| Cables | Connector insertion depth and comfortable bend space |
| Fasteners | Screw diameter/length and standoff geometry |

Add manufacturing clearance deliberately after measurement. Do not report design assumptions as measured dimensions.

## CAD sequence

1. Fill enclosure internal dimensions based on a physical layout and cooling clearance.
2. Fill OLED/LED/port positions and the measured Pi mount centers in the SCAD file.
3. Render the base, inspect collisions, then export a test fit.
4. Add OLED mounts, microphone opening, final speaker grille, amplifier mounts and lid retention for the chosen hardware. These are deliberately unfinished in the starter.
5. Render `part="lid"`; verify vent placement and fastening.
6. Fit all hardware, check strain relief, and run the enclosed thermal/audio tests before final printing.

The starter's 2.4 mm wall/lid thickness is an initial design choice; revise for the fabrication process. No finished STL is provided because hardware dimensions and mounting locations have not been measured.
