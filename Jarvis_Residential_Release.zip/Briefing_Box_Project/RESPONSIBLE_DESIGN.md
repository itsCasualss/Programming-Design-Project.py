# Responsible design

The chosen demonstration uses only fictional calendar events and Demo Item A/B reminder labels. It contains no real medicine names, dosing recommendations, identifying health data, or private calendar credentials. Both screen titles and speech identify demo results.

Reminder times are scheduling fixtures. The application never claims that an item was taken or missed, never tells a user to double or catch up a dose, and never dispenses anything. A past timestamp is not proof of a missed action. It shows upcoming scheduled occurrences, including tomorrow when necessary. Repeated queries are read-only. This student prototype is not a dependable medical alarm.

Wake/command audio is processed locally in memory using openWakeWord and Vosk. The application does not persist microphone recordings. Speech WAV files exist briefly in a temporary directory and are removed after playback. Weather/news require network access; local calendar/pills do not. The real private-calendar option requests its configured feed over HTTPS.

If private data is ever added, keep `config.local.json` and private data out of shared submissions, set restrictive file permissions and inspect the package before sharing. Console output and the screen contain briefing text by design, so private testing should not be recorded or shared. Logs contain states and error classes rather than private URLs, raw audio or medical names; rotation bounds log size.

Third-party libraries and official voice models are used as allowed examples in the project description. Review model licenses for any use beyond the class demonstration; do not imply these models were trained by the team. The team's own contribution is application design, integration, validation and explanation. AI-assisted code and drafts must be reviewed/adapted and described honestly in the personal development record, subject to course instructions.
