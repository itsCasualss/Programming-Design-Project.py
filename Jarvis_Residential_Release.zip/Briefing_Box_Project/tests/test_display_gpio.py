"""Compatibility entrypoint for the earlier manual Member 3 demonstration."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from role3_demo import main
if __name__ == '__main__': main()
