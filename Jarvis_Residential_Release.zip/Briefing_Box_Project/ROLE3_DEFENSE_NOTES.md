# Member 3 defense notes

Your highest-value preparation is understanding and demonstrating the code you are responsible for. This package does not establish that you personally wrote or tested every line.

## What to be able to explain

- `main.py`: why the transition table permits listening→processing but rejects idle→output; how `finally` restores idle after failure.
- `display_interface.py`: why text wraps at 20 characters and four lines; how pagination avoids deleting long results; why Tk's main thread reads a queue.
- `gpio_control.py`: BCM17 versus physical pin 11, series resistor, and off/on/blink patterns.
- `presenter.py`: why services return structured data and speech/display come from a single result.
- `role3_demo.py`: how to prove the subsystem without a microphone, API, or teammate's code.

## Concise answers

**Why OLED?** The assignment allows a condensed OLED readout. Full speech and optional Tk desktop output carry the longer content. Actual readability must be tested.

**Why Tk as well?** The Member 3 description names Tkinter. Keeping a working desktop interface makes that work reviewable without changing the integrated OLED plan.

**What is your non-trivial algorithm?** An explicitly validated finite-state machine plus bounded text pagination. Trace both success and error paths, and explain linear text wrapping and the fixed limits.

**What happens on a network failure?** The service returns an error result; the controller enters error, presents it and returns idle. No fake live data is substituted.

**Why not just use more features?** The rubric gives most individual weight to complete subsystem functionality. A dependable integrated demonstration and clear explanation are higher priority than adding unrelated commands.

## Practice before the defense

1. With notes closed, trace Schedule from wake through output to idle.
2. Explain what happens when the command times out.
3. Point to the exact resistor and distinguish physical/BCM numbering.
4. Change a test headline so it spans three OLED pages, then show how the algorithm handles it.
5. Run the tests, explain one failure test and identify which parts still need hardware.
6. Record your actual edits, tests and observations in the individual report. Do not copy claims about work you did not do.
