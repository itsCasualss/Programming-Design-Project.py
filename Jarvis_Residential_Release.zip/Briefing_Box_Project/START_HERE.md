# Latest dashboard upgrade

Read [DASHBOARD_UPGRADE.md](DASHBOARD_UPGRADE.md) first. It supersedes the older dashboard and command-line data-entry instructions below.

# Jarvis · Residential dashboard release

This is the consolidated project, not a patch. Read this file before older notes.

## Update your working Pi copy

Stop the running app with q or Ctrl+C. Extract this release beside your existing
project (for example `~/Desktop/Jarvis_Release/Briefing_Box_Project`). Then run:

```bash
cd ~/Desktop/Jarvis_Release/Briefing_Box_Project
python3 install_update.py ~/Desktop/Briefing_Box_Project
cd ~/Desktop/Briefing_Box_Project
DISPLAY=:0 .venv/bin/python main.py --hdmi --no-audio
```

The updater creates a dated backup of source/config/data, preserves your current
config, data, models and .venv, and installs updated code and documentation.
It does not reinstall dependencies. Fresh installations: follow PI_SETUP.md.

Enter wakes the dashboard; type schedule, pills, weather or news in that terminal.
The options fade in and the prompt appears. Results stay for 60 seconds; Enter
returns to idle. F11 toggles fullscreen; Escape closes the window. Longer news
can be scrolled on the monitor. Keyboard mode is labeled; no microphone is implied.
With a microphone, models and voice dependencies installed, add `--voice`.
Remove `--no-audio` when testing a speaker. The spoken prompt is exactly:
“What would you like me to assist you with?”

## Personal data setup

```bash
.venv/bin/python setup_personal.py calendar
.venv/bin/python setup_personal.py reminders
```

Calendar setup accepts a hidden private HTTPS ICS link, or appends a local event
with date/time in your configured timezone. Reminder setup appends a named daily
reminder with one or more 24-hour times. Repeat to add more. Restart the app.
Your entries go into separate personal files; original demo fixtures stay intact.
The wizard keeps config.local.json private (owner-only permissions). Do not share
that file or your personal data folder. Reminders report scheduled times only;
they do not record whether medication was taken or trigger background alarms.
No personal calendar or medication data has been invented or configured for you.
Until you run setup, these services remain clearly labeled demonstrations.

## TFT recovery and simultaneous TV output

The previous --hdmi option intentionally disables SPI. Use --dual for both.
The app now uses configurable SPI pins/speed, a conservative 1 MHz default,
software backlight control disabled for the documented always-powered LED,
and the same briefing/state on both screens. TFT text is paginated; the clock
and wake screen return when idle. This is shared content, not pixel mirroring.

Close the app, then:

```bash
.venv/bin/python tft_diagnose.py
DISPLAY=:0 .venv/bin/python main.py --dual --no-audio
```

The diagnostic checks for /dev/spidev0.0, tries common ST7735 offset/color
profiles at 500 kHz, and saves only a profile you visually confirm. Use
`--rotation 0` (or 1/2/3) to test orientation. It shows red, green, blue bands,
white border and text. A fully white screen is NOT a successful test. If no
profile produces pixels, power down before checking wiring in WIRING.md.
Verify controller and module marking; a different controller needs its own driver.
A white backlight does not prove the controller receives reset/clock/data.
Do not change supply voltage or bypass resistors as a software troubleshooting step.
--dual requires the TFT driver to initialize; failures are visible, not silently
reported as success. Driver initialization cannot detect a disconnected SPI screen.
The physical white-screen fault remains unconfirmed until this test runs on the Pi.

## Team integration

All files from Austin’s original ZIP are preserved byte-for-byte in vendor/austin.
His original recognize_command(model), record_audio and parse_command functions
are used in --voice mode via austin_adapter.py. Our existing engine supplies
Hey Jarvis wake detection because his wake_word.py is empty. His capture window
is three seconds. Our existing speaker supplies speech; his standalone pyttsx3
module is preserved but not used. No files in vendor/austin should be edited.
To compare the previous recognizer, set voice.command_backend to "builtin" in
config.local.json. The default backend is "austin". The adapter resolves his
bare import without replacing our modules, uses our model path and honors the
configured microphone. Physical voice/audio still needs hardware testing.

## Scope and remaining work

Implemented: residential Tk dashboard, wake fade/prompt, persistent responses,
Austin adapter, personal-data wizard, dual display, TFT diagnostic, safe updater.
Still required: physical TFT confirmation, microphone/speaker testing, enclosure,
full reboot/demo rehearsal, and instructor confirmation of the chosen small
screen against the display criterion. Fixed four-service workflow; no chatbot.
