# Audit changes

## Defects and omissions corrected

| Earlier implementation | Change and reason |
|---|---|
| RSS parser fetched a URL directly without a request timeout | Fetch bytes with timeout/size checks, then parse; prevents routine network failures from hanging the interaction indefinitely |
| Calendar walked only raw events and used current system date without recurrence support | Expand recurrence in America/New_York, filter cancelled events, sort; controlled schedule remains useful on later demo days |
| Pills called both past/future entries “due” using an absolute time window | Show next scheduled occurrences and unknown taken status; rollover is tested |
| OLED truncated overflow; no Tk interface | Add pagination and queued Tk dashboard; preserve OLED as integrated screen |
| State changes were spread between main and presenter | Central transition table and controller-owned state changes; test exact success/error sequences |
| Direct espeak playback assumed correct output | Generate WAV and use the user session's normal player; explicit failure result |
| Voice errors silently switched to keyboard | Explicit voice mode preflight; keyboard/scripted modes remain available by choice |
| Wake loader loaded all models/default backend | Load only Hey Jarvis with ONNX and reset buffers between wake sessions |
| Runtime could download Vosk automatically | Explicit setup with local model validation; deterministic startup |
| Audio queues were unbounded | Bounded queues and nonblocking callbacks |
| OLED/GPIO caught only initialization failures | Catch runtime disconnection, expose degraded state, preserve console/Tk |
| “Tests” were mostly manual output scripts | Add assertion-based offline regression suite and human-confirmed hardware checks |
| Unversioned all-in-one dependencies | Pin portable packages; separate Pi dependencies; document ONNX packaging exception |
| README assumed USB speaker and unconditional autostart | Bluetooth development guide, interchangeable output, conditional user service |
| No report scaffolds or rubric mapping | Add report drafts, evidence checklist, project-specific rubric audit |

## Preserved decisions

Pi 4B, Python/Linux, four commands, openWakeWord/Vosk, SSD1306 OLED allowance, GPIO17 LED, module separation, local controlled calendar, local reminder data, Open-Meteo/RSS, and a simple class-project scope remain. No conversational AI, cloud speech recognition, or new electronics purchases are introduced.

## Limitations deliberately retained

No real medication tracking/dispensing. No always-running reminder alarm. No touchscreen requirement. Bluetooth reconnect depends on the OS session and speaker. Small OLED uses an ASCII bitmap readout while Tk holds full text. Final mechanical dimensions and real performance numbers cannot be created from missing measurements.
