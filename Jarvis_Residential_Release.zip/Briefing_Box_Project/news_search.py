"""Public Google News RSS aggregation, not a full-article or AI service."""
from urllib.parse import urlencode,urlparse
from services import clean_text,result

def fetch_news(service,query=''):
    import feedparser
    query=' '.join(query.split())[:120]
    if service.config.get('offline'):
        if query:raise ValueError('Keyword search needs an internet connection')
        return service.news()
    base='https://news.google.com/rss'
    params={'hl':'en-US','gl':'US','ceid':'US:en'}
    if query:base+='/search';params['q']=query
    url=base+'?'+urlencode(params)
    try: raw=service.fetch(url)
    except OSError: raw=service.fetch(url)  # one bounded retry for a transient connection failure
    feed=feedparser.parse(raw)
    if feed.bozo:raise ValueError('Unreadable news feed')
    stories=[];publishers=set();titles=set()
    for entry in feed.entries:
        source=entry.get('source',{})
        publisher=clean_text(source.get('title',''),100)
        key=urlparse(source.get('href','')).hostname or publisher.casefold()
        title=clean_text(entry.get('title',''),240)
        if not publisher or not title or key in publishers or title.casefold() in titles:continue
        link=entry.get('link','')
        if not link.startswith('https://'):continue
        summary=clean_text(entry.get('summary',''),900)
        if summary.replace(publisher,'').strip() in (title,title.removesuffix(' - '+publisher)) or len(summary)<len(title)+20:
            summary='Open the source link for the full article; this feed supplies a headline only.'
        stories.append({'title':title,'summary':summary,'published':entry.get('published',''),'publisher':publisher,'link':link})
        publishers.add(key);titles.add(title.casefold())
        if len(stories)==3:break
    if not stories:raise ValueError('No matching publishers found; try broader keywords')
    return result('news',{'headlines':[s['title'] for s in stories],'stories':stories,
        'query':query,'coverage':f'{len(stories)} of 3 requested publishers found.'},'Google News RSS',False)
