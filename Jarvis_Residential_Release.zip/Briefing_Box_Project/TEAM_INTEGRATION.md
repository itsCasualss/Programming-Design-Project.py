# Team integration contract

Use `ARCHITECTURE.md` for interfaces. The primary calls are:

```python
command = voice.listen_for_command(timeout_seconds=8)  # schedule/pills/weather/news/None
briefing = services.dispatch(command)                 # structured result
presenter.present(briefing)                           # full speech + screen text
```

The main controller owns state transitions. Services must not change GPIO or display widgets. Voice code must not call APIs. The presenter must not fetch data. Tk widgets are accessed only by the main thread.

The old service result format with `speech` and `display` is retained for errors only. Teammates adopting the updated package must return structured success data; do not mix old and new service modules. `tests/test_core.py` contains end-to-end examples.

1. Member 1 validates microphone/model setup and real speech output.
2. Member 2 validates controlled calendar/pills and live API/RSS responses.
3. Member 3 validates OLED/Tk/GPIO and all state transitions.
4. Team merges the complete folder, runs software tests, then repeats physical tests.

The assignment describes three members unless instructor-approved otherwise. Earlier planning mentioned four teammates; document the approved allocation rather than inventing a fourth rubric role. This does not block implementation, but it should be settled before reports are submitted.
