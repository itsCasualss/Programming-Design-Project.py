# TFT edition: start here

This update selects the ST7735S 128x160 SPI display. Older OLED wiring instructions
apply only if selecting backend ssd1306. TFT hardware has NOT been physically tested.

Power disconnected: VCC to physical pin 1 (3.3V); GND to shared pin 6 ground;
CS to 24 (GPIO8); RESET to 22 (GPIO25); A0 to 18 (GPIO24);
SDA to 19 (GPIO10 MOSI); SCK to 23 (GPIO11).
LED backlight to 3.3V through its own 330-ohm resistor for initial testing.
This may be dim; do not bypass the resistor without confirming module circuitry.
Separate status LED: pin 11 (GPIO17), 330-ohm resistor, anode; cathode to ground.
Leave SD-card pins unused. TFT SDA is not I2C SDA. Pins 3/5 are unused.

Use this document instead of the older OLED setup notes.
For the current Desktop location, in a Pi terminal:

```bash
cd ~/Desktop/Briefing_Box_Project
bash install.sh --keyboard
sudo reboot
```

After reboot:
```bash
cd ~/Desktop/Briefing_Box_Project
bash verify_pi.sh
```

The first test needs no microphone or network. Verify red, green, blue, white,
then readable text with a visible border on all four edges. SPI cannot confirm
that a panel is attached: successful execution alone is NOT a hardware pass.
If red/blue swap, set display.bgr to true in config.local.json.
If edges are shifted, panel variants may require h_offset/v_offset adjustment;
record the observed shift before changing them. rotate accepts 0,1,2,3.
Never alter wires while powered.

verify_pi.sh checks all imports and SPI/GPIO access, runs software tests, displays
the color test (press Enter when prompted), then runs the four-service scripted
demo on the TFT and GPIO17 LED with audio explicitly disabled. Its final unknown
command is an intentional recovery test, not a setup failure.
Full output is in reports/pi-verification-latest.log. Setup output is in
reports/install-latest.log. Both stop on failure instead of continuing silently.

After visual verification, keyboard operation with sample data and no audio:
```bash
GPIOZERO_PIN_FACTORY=rpigpio .venv/bin/python main.py --offline --no-audio
```
Press Enter to wake, then type schedule, pills, weather, or news. q quits.
This is NOT microphone recognition. Fixture information is synthetic.
Pair/select/test the Bluetooth speaker separately before removing --no-audio.
When a microphone is available, bash install.sh --voice adds optional recognition
dependencies; setup_models.py downloads models. That optional profile and physical
voice recognition have not been validated on this Pi. openwakeword intentionally
omits its unused TFLite dependency, so pip check is not a clean voice-profile gate.

Continue with Bluetooth instructions and keyboard mode in PI_SETUP.md.
Skip OLED I2C detection steps. No microphone is needed until voice integration.
The original package's OLED-specific validation claims do not validate this TFT.
