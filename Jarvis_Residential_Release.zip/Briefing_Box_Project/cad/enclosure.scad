// Parametric enclosure STARTER. Units mm. Not a measured/fabrication-ready design.
// All zeros below must be replaced by measurements plus deliberate clearances.
// Set part="lid" to export the lid separately after completing the measurements.
part = "base";
inner_w = 0;
inner_d = 0;
inner_h = 0;
wall = 2.4; // Design choice, not a component measurement.
lid_thickness = 2.4;
// Front-face OLED window location measured from internal lower-left corner:
oled_x = 0;
oled_z = 0;
oled_w = 0;
oled_h = 0;
led_x = 0;
led_z = 0;
led_d = 0;
// Right-side cable/port opening, verify connector insertion clearance:
port_y = 0;
port_z = 0;
port_w = 0;
port_h = 0;
// Measured PCB mounting-hole centers relative to inside left/front:
mount_holes = [];
standoff_h = 0;
standoff_d = 0;
screw_d = 0;
assert(inner_w > 0 && inner_d > 0 && inner_h > 0, "Fill measured enclosure dimensions first");
assert(oled_w > 0 && oled_h > 0 && led_d > 0, "Measure OLED window and LED");
assert(port_w > 0 && port_h > 0, "Measure port opening");
assert(len(mount_holes) >= 4 && standoff_h > 0 && screw_d > 0 && standoff_d > screw_d, "Measure mounting geometry");
assert(oled_x >= 0 && oled_x+oled_w <= inner_w && oled_z >= 0 && oled_z+oled_h <= inner_h, "OLED exceeds enclosure");
module base() {
    difference() {
        cube([inner_w+2*wall, inner_d+2*wall, inner_h+wall]);
        translate([wall,wall,wall]) cube([inner_w,inner_d,inner_h+1]);
        translate([wall+oled_x,-1,wall+oled_z]) cube([oled_w,wall+2,oled_h]);
        translate([wall+led_x,wall+1,wall+led_z]) rotate([90,0,0]) cylinder(d=led_d,h=wall+2,$fn=32);
        translate([inner_w+wall-1,wall+port_y,wall+port_z]) cube([wall+2,port_w,port_h]);
    }
    for (p=mount_holes) translate([wall+p[0],wall+p[1],wall]) difference() {
        cylinder(d=standoff_d,h=standoff_h,$fn=32);
        translate([0,0,-.1]) cylinder(d=screw_d,h=standoff_h+.2,$fn=24);
    }
}
module lid() {
    difference() {
        cube([inner_w+2*wall,inner_d+2*wall,lid_thickness]);
        // Vent slots; confirm fan clearance and avoid components below the slots.
        for (x=[wall+8:8:inner_w-4]) translate([x,wall+8,-1]) cube([3,inner_d-16,lid_thickness+2]);
    }
}
if(part=="base") base(); else if(part=="lid") lid(); else assert(false,"part must be base or lid");
// Lid retention, OLED mounts, mic opening and final speaker grille depend on actual hardware.
// Add those after measurement; do not submit this starter as completed final CAD.
