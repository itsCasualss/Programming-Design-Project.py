# Bluetooth development audio

Keep the powered Bluetooth speaker. The application creates speech as a temporary WAV and uses `pw-play`, `paplay`, or `aplay` to play it through Linux. No speaker name, MAC address, or GPIO audio circuit is hard-coded into the app. Model-generated audio files are deleted after playback.

## Pair in the Pi desktop session

1. Power the speaker and put it into pairing mode. Disconnect its active connection to your phone if needed.
2. Use the Pi desktop Bluetooth menu to add/pair the device.
3. Select it as the sound output using the desktop sound menu. Keep the USB microphone as input; avoid the speaker's hands-free microphone profile.
4. Start at a moderate volume and test.

Optional terminal pairing, replacing `MAC_ADDRESS` with the actual address shown by scanning:

```text
bluetoothctl
power on
agent on
default-agent
scan on
pair MAC_ADDRESS
trust MAC_ADDRESS
connect MAC_ADDRESS
scan off
quit
```

Trust permits reconnection; it does not prove this particular speaker reconnects automatically after every boot.

## Verify the output

For PipeWire:

```bash
wpctl status
wpctl set-default SINK_ID
wpctl set-mute @DEFAULT_AUDIO_SINK@ 0
wpctl set-volume @DEFAULT_AUDIO_SINK@ 0.5
```

Replace `SINK_ID` with the numeric speaker sink shown by `wpctl status`. IDs can change. Do not copy another machine's ID. Run as the desktop user, not with sudo.

For a PulseAudio session, use `pactl list short sinks` and `pactl set-default-sink ACTUAL_SINK_NAME`, and choose `"player": "paplay"` in `config.local.json`. For plain ALSA wired output, use `aplay`; Bluetooth may not appear in `aplay -l` because it belongs to the audio server, not a USB sound card.

Test through exactly the application's speech path:

```bash
python -c "from config import load_config; from speech_output import Speaker; print(Speaker(load_config()['speech']).speak('Briefing Box audio check'))"
```

A `True` result means the player process succeeded. You must still hear it from the intended speaker. Sound going to HDMI is not a pass. If the speaker disconnects, Linux may select another sink; the app cannot establish that a human heard the output.

## Reconnect tests

Record results for three cold boots, speaker off/on, and Bluetooth disconnect/reconnect. On reconnect, inspect the default sink again and rerun the speech test. If necessary, use `bluetoothctl connect MAC_ADDRESS` before launching. Automatic reconnect should be accepted only after it passes your actual boot tests; use manual launch for the demonstration until then.

## Later hardware swap

| Final choice | What changes |
|---|---|
| Powered AUX speaker | Pi 4 3.5 mm cable, select analog output |
| USB audio speaker/DAC | Plug in device, select its Linux output |
| I²S amplifier/HAT + bare speaker | Correct wiring/overlay/driver, select new ALSA/PipeWire output |
| Analog amplifier + 8 Ω speaker | Pi analog audio into amplifier input, amp power and speaker wiring |

The bare 8 Ω / 2 W speaker requires an amplifier. Its 2 W marking is a rating, not the power it must always receive. Do not attach it directly to GPIO or assume a speaker's USB charging connector carries audio. Keep the existing OLED/LED GPIO allocation when teammates choose audio hardware. Retest prompt, playback, echo, boot, and enclosure fit after the swap.

Bluetooth is a development choice. The final assignment also requires a self-contained enclosure housing the components; an external development speaker is not evidence that this hardware criterion is finished.
