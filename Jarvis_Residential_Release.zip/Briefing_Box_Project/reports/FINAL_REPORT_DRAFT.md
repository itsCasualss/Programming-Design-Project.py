# Final group report draft

**Not submission-ready until the evidence fields below are completed.**

## System and requirements

The Raspberry Pi application uses local wake-word detection, a fixed voice menu, four information services, spoken output, an integrated OLED and a GPIO indicator. An optional Tkinter interface displays full text. Requirement mapping is in `RUBRIC_AUDIT.md`.

## Implementation

Describe the architecture using `ARCHITECTURE.md`, naming what each member actually implemented/adapted. State final OS/Python, model versions, microphone, speaker/amplifier, OLED and wiring. Include measured final CAD and photos rather than the incomplete starter as final evidence.

## Algorithms

Explain the finite-state machine, fixed recognition grammar, recurrence/time-zone parsing, next-occurrence reminder calculation and OLED pagination. Identify which teammate owns each algorithm and the alternatives actually considered.

## Results

Software regression evidence: `VALIDATION.md`.

| Physical metric | Actual result | Test conditions |
|---|---|---|
| Wake detection | [successes/attempts] | [distance/noise] |
| Commands | [each command successes/attempts] | [speaker/mic placement] |
| Wake→prompt latency | [median/worst] | [sample count] |
| Command→answer latency | [median/worst] | [service/network] |
| Cold boots | [passed/attempted] | [audio reconnect method] |
| Soak test | [duration/issues] | [final enclosure] |

## Responsible design and limitations

Summarize `RESPONSIBLE_DESIGN.md`. Distinguish fictional fixtures, actual live results, mock tests and physical tests. State unresolved failures honestly and their consequences.

## Deliverables and contribution record

[Link final video, measured CAD, source package, as-built wiring, personal reports and actual contribution log. Add citations/licenses and describe assistance as required by the instructor.]
