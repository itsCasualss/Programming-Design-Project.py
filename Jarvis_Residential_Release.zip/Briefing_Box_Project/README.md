# New consolidated release

Start with [START_HERE.md](START_HERE.md) for the residential dashboard, safe update, personal setup, and dual-display test. Older instructions below remain reference material.

# Briefing Box · EEL 4835

**TFT update:** Start with **START_TFT.md**. Default display is now the ST7735S
128x160 SPI TFT. Older OLED-specific sections apply only to the optional SSD1306
backend. Physical TFT operation remains unverified until the Pi screen test.

An audited development package for the Raspberry Pi voice briefing assistant. Software tests are complete as recorded in `VALIDATION.md`; physical qualification and submission evidence remain outstanding. Start with `PI_SETUP.md` when sitting at the Pi.

## Quick software demonstration

On a Linux computer with Python 3.11 or newer:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest discover -s tests -p 'test_*.py' -v
python main.py --demo
```

`--demo` uses the real state machine and service parsers with scripted input and synthetic fixtures. It disables physical audio, GPIO, and OLED. It proves software behavior, not voice recognition or hardware.

If a graphical desktop and Tkinter are available:

```bash
python main.py --demo --tk
python role3_demo.py --tk
```

## Pi development sequence

1. Use 64-bit Raspberry Pi OS **with Desktop** on the Pi 4B and 32 GB card. Keep an existing usable installation; inspect its version before changing anything.
2. Copy this directory to `~/Briefing_Box_Project`.
3. Follow `WIRING.md` with power disconnected.
4. Run `bash install.sh`, activate `.venv`, then `python setup_models.py`.
5. Pair the powered Bluetooth speaker and select its output in the **same user session** that runs Python. Follow `BLUETOOTH_AUDIO.md`.
6. Run `python tests/hardware_test.py` and `python role3_demo.py --hardware`.
7. Run `python main.py --offline` for keyboard integration with real hardware.
8. Run `python main.py --voice --offline` for real voice with controlled fixtures.
9. Run `python main.py --voice` for live weather/news with controlled calendar/pills.

Add `--tk` to show the desktop dashboard. OLED and Tk can run together; the OLED remains the integrated display.

## Data choices

| Service | Default | Offline mode |
|---|---|---|
| Schedule | Local fictional `.ics`, recurring daily at 9:00 AM, 1:00 PM and 3:30 PM, America/New_York | Same |
| Pills | Fictional Demo Item A at 08:00/20:00 and Demo Item B at 13:00 | Same |
| Weather | Open-Meteo, Tampa, Fahrenheit/mph | Clearly labeled synthetic fixture |
| News | BBC RSS, up to three headlines | Clearly labeled fictional engineering headlines |

Calendar/pills always identify themselves as demonstration data. Pills shows the next scheduled occurrences and explicitly leaves taken status unknown. No real medicines, doses, catch-up instructions, dispensing, or adherence claims. Repeated queries do not alter reminder status. This is an on-demand briefing, not a background alarm system.

Private `.ics` URL support remains available in `config.local.json`; it is optional for this team's controlled demo. Live failures produce an error, never a silent substitution of fake data.

## Architecture and ownership

| Module | Responsibility | Assigned subsystem |
|---|---|---|
| `voice_interface.py`, `speech_output.py` | Wake word, fixed grammar, WAV/audio playback | Member 1 |
| `services.py`, `data/` | Fetching, validation, calendar recurrence, next reminder logic | Member 2 |
| `main.py`, `display_interface.py`, `gpio_control.py`, `presenter.py` | State machine, Tk/OLED, GPIO, output formatting | Member 3 |
| `role3_demo.py`, tests and integration docs | Independent demonstration and verification | Member 3 / team |

These are proposed ownership boundaries, **not claims about who personally authored or tested the work**. Each teammate must review, adapt, understand, and document their contribution. See `reports/` and `ROLE3_DEFENSE_NOTES.md`.

## Important files

- `PI_SETUP.md`: exact bring-up sequence and troubleshooting.
- `BLUETOOTH_AUDIO.md`: pairing, output selection, reboot tests, later hardware swaps.
- `WIRING.md`: physical header numbers and breadboard plan.
- `ARCHITECTURE.md`: state transitions, threading, algorithm justification.
- `RUBRIC_AUDIT.md`: requirement-to-evidence mapping and remaining gaps.
- `VALIDATION.md`, `TEST_PLAN.md`: automated results versus physical tests still required.
- `DEMO_SCRIPT.md`: recording sequence and individual demonstration.
- `ENCLOSURE_LAYOUT.md`, `cad/enclosure.scad`: measurement-driven enclosure starter.
- `AUDIT_CHANGES.md`: defects addressed and decisions preserved.

No guarantee of a grade is possible from software alone. A working enclosure, real voice demo, reliability results, reports, and your explanation of Member 3 determine the remaining evidence.
