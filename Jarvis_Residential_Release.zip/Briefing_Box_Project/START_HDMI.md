# HDMI first test
Connect the TV to micro-HDMI nearest USB-C power. Boot into the Pi desktop.
Run these commands in Terminal ON THE PI DESKTOP, not in an ordinary SSH session:

```bash
cd ~/Desktop/Briefing_Box_Project
sudo apt install -y python3-tk
.venv/bin/python main.py --hdmi --demo --no-audio
```

The fullscreen window cycles through the four services and an intentional error-recovery example, then closes. Weather/news are labeled synthetic fixtures. This first test disables GPIO, SPI and audio. F11 toggles fullscreen; Escape closes.

For keyboard interaction, run:
```bash
.venv/bin/python main.py --hdmi --offline --no-audio
```
Use the terminal: Enter wakes, then type schedule, pills, weather or news. Alt+Tab switches between dashboard and terminal. This mode retains configured GPIO behavior. Microphone and audio are not validated by either test.

The HDMI option disables only the small display at runtime and preserves the configuration files. Existing TFT commands remain available. Do not run install.sh again for this update.

Validation: existing unit suite run in build environment; physical HDMI, Pi graphics session and keyboard interaction require on-device verification.
