# Member 3 wiring plan

**For the current TFT build, use START_TFT.md instead. The table and SVG below
describe the previous OLED build, not the TFT.**

Open `WIRING.svg` for the labeled connection drawing.

Target: Raspberry Pi 4B, 3.3 V-compatible 128×64 I²C SSD1306 OLED, one LED, 330 Ω series resistor, USB microphone, powered Bluetooth development speaker. Check the actual OLED labels: pin order varies by vendor.

| Connection | Physical header pin | BCM signal |
|---|---:|---|
| OLED VCC | 1 | 3.3 V |
| OLED GND | 6 | Ground |
| OLED SDA | 3 | GPIO2 / SDA1 |
| OLED SCL | 5 | GPIO3 / SCL1 |
| LED resistor input | 11 | GPIO17 |
| LED cathode return | 9 | Ground |

**Power off, shut down, and unplug Pi power before changing wires.** Pin 1 is the square-pad/3.3 V corner shown in the Pi header documentation; verify board orientation, not a photo's left/right. Never connect SDA/SCL to 5 V. If the module requires a different voltage or has pull-ups to 5 V, stop and identify it before connecting.

## Breadboard assembly

1. Connect physical pin 9 to the breadboard ground rail. Some rails split in the middle; bridge only if you intend to use both halves and confirm continuity with a meter.
2. Insert the LED with its two legs in different connected rows. The long leg is normally anode (+); the flat case edge marks cathode (−). Confirm if leads were trimmed.
3. Connect GPIO17 physical pin 11 to one end of a 330 Ω resistor.
4. Connect the other resistor end to the LED anode row.
5. Connect the LED cathode row to the ground rail.
6. Connect the OLED using the four mappings above. Keep wires short and avoid stressing its header.

The electrical path is GPIO17 → resistor → LED anode → LED cathode → ground. There is no direct GPIO-to-ground wire. With a typical red LED around 2 V, 330 Ω gives roughly 4 mA; actual current depends on forward voltage. A 220 Ω resistor is also part of the original plan, but 330 Ω is the conservative default here.

## Bring-up observations

| Test | Expected physical observation |
|---|---|
| `i2cdetect -y 1` | Actual OLED address visible; usually 3c, sometimes 3d |
| `python role3_demo.py --hardware` | Readable standby/menu/results and all LED patterns |
| Idle | LED off |
| Prompt/listening | LED steadily on |
| Processing | LED blinks at 0.18 s on / 0.18 s off |
| Output | LED steadily on |
| Error | Five 0.10 s on/off blinks, then idle |

The code deliberately reuses solid-on for listening and output; the display distinguishes those states. A console message is not proof that GPIO or OLED is functioning. The strict hardware test exits on initialization failure.

## Audio

USB microphone plugs into USB. Bluetooth speaker uses its own power/amplifier and has no GPIO connection. Keep physical audio-hardware decisions separate until the team specifies the amplifier. No amplifier pinout is assumed in this package.
